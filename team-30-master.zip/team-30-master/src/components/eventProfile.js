import React, { useState, useEffect } from 'react'
import firebase from 'firebase';
import { useAuth } from "../contexts/AuthContext"
import "../css/admin.css"
import image from "C:/Users/Abhishek/Desktop/Projects/cfg-hackathon/src/images/hunger.png"

export default function UserProfile({ user }) {



    const deleteUser = () => {
        const useRef = firebase.database().ref("user-prof").child(user.id);
        useRef.remove();
    }

    const updateUser = () => {
        const useRef = firebase.database().ref("user-prof").child(user.id);
        useRef.update({
            status: !user.status
        });
    }
    // const [pdfUrl, setPdfUrl] = useState([]);




    return (
        <div className="pos-cent">
            <br />   <br />   <br />
            <div className="two">
                <div className="c">
                    <div className="i"><img className="img" src={image} /></div>
                    <div className="name"><b>{user.name}</b><br />
                        <div className="role">
                            <br />
                            {user.date}
                        </div>
                        <br />
                    </div>
                </div><br /><br />
                {user.desc}<br />
                <button className="btn btn-sm btn-warning" onClick={deleteUser}>Delete</button>&nbsp;&nbsp;
                <button className="btn btn-sm btn-warning" onClick={updateUser}>Update</button>&nbsp;&nbsp;
                {/* <button className="btn btn-sm btn-warning" onClick={updateUser}>Show</button><br /><br /><br /> */}
            </div>

            {/* <h1>{user.name}</h1>
            <p>{user.desc}</p>
            <p>{user.date}</p> */}

        </div>
    )
}
