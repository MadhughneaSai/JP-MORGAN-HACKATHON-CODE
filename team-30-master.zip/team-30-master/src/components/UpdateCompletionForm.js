import React, { useState, useEffect } from 'react';
import firebase from '../firebase';
import { v4 as uuid } from 'uuid';
import { useAuth } from "../contexts/AuthContext"

export default function CRUD3({ event }) {
    const [pdfUrl, setPdfUrl] = useState([]);

    const readPdfs = async (e) => {
        const file = e.target.files[0];
        const id = uuid();
        const storageRef = firebase.storage().ref('docs').child(id);
        const pdfRef = firebase.database().ref('docs').child(id);
        await storageRef.put(file);
        storageRef.getDownloadURL().then((url) => {
            pdfRef.set(url);
            const newState = [...pdfUrl, { id, url }];
            setPdfUrl(newState);
        });
    };

    const getPdfUrl = () => {
        const pdfRef = firebase.database().ref('docs');
        pdfRef.on('value', (snapshot) => {
            const pdfUrls = snapshot.val();
            const urls = [];
            for (let id in pdfUrls) {
                urls.push({ id, url: pdfUrls[id] });
            }
            const newState = [...pdfUrl, ...urls];
            setPdfUrl(newState);
        });
    };
    const deletePdf = (id) => {
        const storageRef = firebase.storage().ref('doc');
        const pdfRef = firebase.database().ref('docs').child(id);
        storageRef.delete().then(() => {
            pdfRef.remove();
        });
    };
    useEffect(() => {
        getPdfUrl();
    }, []);
    const [desc, setDesc] = useState("")
    const [hour, setHour] = useState("")

    const { currentUser } = useAuth()


    const handleDescOnChange = (e) => {
        setDesc(e.target.value);
    };
    const handleHoursOnChange = (e) => {
        setHour(e.target.value);
    }
    const upload = () => {
        const ref = firebase.database().ref("volunteer");
        ref.get().then((snap) => {
            const val = snap.val();
            for (let id in val) {
                if (currentUser.email === val[id].email) {
                    ref.child(id).push({ name: "abhi" });
                    // console.log(val[id].fname);
                }
            }
        })
    }

    // // useEffect(() => {
    // const addDetails = () => {
    //     const userRef = firebase.database().ref("event");
    //     userRef.on('value', (snapshot) => {
    //         const users = snapshot.val();
    //         const userList = [];
    //         const breaker = true;
    //         for (let id in users) {
    //             console.log(id);
    //             const partRef = firebase.database().ref("event").child(id).child("participant");
    //             partRef.on('value', (snapshot) => {
    //                 const parts = snapshot.val();
    //                 const partList = [];
    //                 console.log("surprise" + currentUser.email);
    //                 for (let x in parts) {
    //                     console.log("hmmm" + parts[x].email);
    //                     if (currentUser.email === (parts[x].email) && breaker ) {
    //                         console.log("yoooo" + parts[x].email)
    //                         console.log("yooooiiiiii" + x)
    //                         const det = {
    //                             desc,
    //                             hour,
    //                             // status: true
    //                             // status: false,
    //                         };
    //                         partRef.child(x).push(det);
    //                         breaker = false;
    //                         // break;
    //                     }
    //                 }
    //             })
    //         }

    //     });
    // }
    // }, []);


    // console.log(currentUser.email);
    // const addDetails = () => {
    //     const userRef = firebase.database().ref("volunteer")
    //     const user = {
    //         desc,
    //         hour,
    //         status: true
    //         // status: false,
    //     };
    //     userRef.push(user);
    // };


    // const someRef = firebase.database().ref("event");
    // someRef.on('value', (snapshot) => {
    //     const x = snapshot.val();
    //     for (let id in x) {

    //     }
    // });
    //const eventRef = firebase.database().ref("event").child(event.id).child("participant")

    // const userRef = firebase.database().ref("volunteer");
    // userRef.on('value', (snapshot) => {
    //     const volunteers = snapshot.val();
    //     const volunteerList = [];
    //     for (let id in volunteers) {
    //         console.log(volunteers[id]);
    //         if (currentUser.email === (volunteers[id].email)) {

    //             const vol = {
    //                 desc, hour, 
    //                 // status: false,
    //             };
    //             eventRef.push(vol);
    //             volunteerList.push({ id, ...volunteers[id] })
    //         }
    //     }
    // });
    return (
        <div>
            {event}
            <h1>Upload imgae</h1>
            {/* <input type="file" accept="images/*" onChange={readPdfs} /> */}
            <input type="text" onChange={handleDescOnChange} value={desc} placeholder="Desc what u did" />
            <input type="number" onChange={handleHoursOnChange} value={hour} placeholder="Num of hrs u worked" />
            {/* {pdfUrl
                ? pdfUrl.map(({ id, url }) => {
                    return (
                        <div key={id}>
                            <h1>{url}</h1>
                            <a href={url} target="_blank">Click</a>
                            <button onClick={() => deletePdf(id)}>Delete</button>
                        </div>
                    );
                })
                : ''} */}
            <button onClick={upload} >Upload</button>
        </div>
    );
}