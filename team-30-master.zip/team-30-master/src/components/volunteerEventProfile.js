import React, { useState, useEffect } from 'react'
import firebase from 'firebase';
import { useAuth } from "../contexts/AuthContext"
import "../css/admin.css"
import image from "C:/Users/Abhishek/Desktop/Projects/cfg-hackathon/src/images/hunger.png"
export default function UserProfile({ event }) {
    const { currentUser } = useAuth()
    const [volunteerList, setVolunteerList] = useState();

    const addUser = () => {
        const eventRef = firebase.database().ref("event").child(event.id).child("participant")

        const userRef = firebase.database().ref("volunteer");
        userRef.on('value', (snapshot) => {
            const volunteers = snapshot.val();
            const volunteerList = [];
            for (let id in volunteers) {
                console.log(volunteers[id]);
                if (currentUser.email === (volunteers[id].email)) {
                    alert("Inside");
                    const vol = {
                        fname: volunteers[id].fname,
                        lname: volunteers[id].lname,
                        email: currentUser.email,
                        phone: volunteers[id].phone,
                        hours: "0",
                        // status: false,
                    };
                    eventRef.push(vol);


                }
            }
        });


    }




    return (
        <div>
            {/* <div className="card" style={{ width: "18rem" }}>

                <div style={{ marginBottom: "10%" }} className="card-body" >
                    <h5 className="card-title" >{event.name}</h5>
                    <p className="card-text">{event.desc}</p>
                    <p className="card-text">{event.date}</p>
                    <a href="#" style={{ top: "84%", left: "15%" }} ><button className="btn btn-primary" onClick={addUser} >Contribute</button></a>
                </div>
            </div> */}
            {/* <h1>{event.name}</h1>
            <p>{event.desc}</p>
            <p>{event.date}</p>
            <button onClick={addUser} >contribute</button> */}
            <div className="pos-cent">
                <br />   <br />   <br />
                <div className="two">
                    <div className="c">
                        <div className="i"><img className="img" src={image} /></div>
                        <div className="name"><b>{event.name}</b><br />
                            <div className="role">
                                <br />
                                {event.date}
                            </div>
                            <br />
                        </div>
                    </div><br /><br />
                    {event.desc}<br />
                    <button onClick={addUser} >contribute</button>
                    {/* <button className="btn btn-sm btn-warning" onClick={updateUser}>Show</button><br /><br /><br /> */}
                </div>

                {/* <h1>{user.name}</h1>
            <p>{user.desc}</p>
            <p>{user.date}</p> */}

            </div>

        </div>
    )
}
