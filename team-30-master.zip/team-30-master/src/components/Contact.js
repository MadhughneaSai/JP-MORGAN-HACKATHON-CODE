import React from 'react';
import "../css/Contact.css"

export default function Contact(){
    return(
        <>
        <div classNameName="intro">
            <h2 classNameName="intro-h2">Youngistaan</h2>

            <p classNameName="intro-p">
            Youngistaan Foundation is an NGO based in India that works to improve the lives of the most underprivileged and disadvantaged people through programs that address: hunger, homelessness, poverty, education inequity, gender inequality, taboos on menstruation, emergency responses, animal rights, capacity building and many more issues.
            </p>
            <p>
            We at Youngistaan Foundation would love to hear from you!
            </p>
            <p>
            IMPORTANT: Youngistaan Foundation does not charge any money for applications for jobs, internships or to volunteer. Please avoid such fraudulent activity and inform Youngistaan Foundation and the authorities immediately
            </p>
        </div>


        <div className="bg-info contact overflow-hiddedn position-relative">
   {/* <!-- Row  -->  */}
  <div className="row no-gutte
rs">
    <div className="container">
      <div className="col-lg-6 contact-box mb-4 mb-md-0">
        <div className="">
          <h1 className="title font-weight-light text-white mt-2">Contact Us</h1>
          <form className="mt-3">
            <div className="row">
              <div className="col-lg-12">
                <div className="form-group mt-2">
                  <input className="form-control text-white" type="text" placeholder="name" />
                </div>
              </div>
              <div className="col-lg-12">
                <div className="form-group mt-2">
                  <input className="form-control text-white" type="email" placeholder="email address" />
                </div>
              </div>
              <div className="col-lg-12">
                <div className="form-group mt-2">
                  <input className="form-control text-white" type="text" placeholder="Phone number" />
                </div>
              </div>
              <div className="col-lg-12">
                <div className="form-group mt-2">
                  <textarea className="form-control text-white" rows="3" placeholder="message"></textarea>
                </div>
              </div>
              <div className="col-lg-12 d-flex align-items-center mt-2">
                <button type="submit" className="btn bg-white text-inverse px-3 py-2"><span> Submit</span></button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div className="col-lg-6 right-image p-r-0">
    <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d8745.175539663642!2d78.42775122715244!3d17.40883903902566!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sBadruka%20Enclave%2C%20Flat%20number%20A%20104%2C%20Rd%20Number%2012%2C%20above%20Andhra%20Bank%2C%20Nandi%20Nagar%2C%20Banjara%20Hills%2C%20Hyderabad%2C%20Telangana%20500034!5e0!3m2!1sen!2sin!4v1625922176360!5m2!1sen!2sin"
        width="100%" height="538" frameborder="0" style={{border:0}} allowfullscreen data-aos="fade-left" data-aos-duration="3000"></iframe>
    </div>
  </div>
</div>
<p className="footer-copyright">
      &copy; Sample Inc. {new Date().getFullYear()}
    </p>
        </>
    )
}