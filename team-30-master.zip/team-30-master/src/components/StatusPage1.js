import React, { useState, useEffect } from 'react'
import firebase from 'firebase';
import { useAuth } from "../contexts/AuthContext"
import { Link } from "react-router-dom"

export default function UserProfile({ event }) {
    // const { currentUser } = useAuth()
    // const [volunteerList, setVolunteerList] = useState();

    // const addUser = () => {
    //     const eventRef = firebase.database().ref("event").child(event.id).child("participant")

    //     const userRef = firebase.database().ref("volunteer");
    //     userRef.on('value', (snapshot) => {
    //         const volunteers = snapshot.val();
    //         const volunteerList = [];
    //         for (let id in volunteers) {
    //             console.log(volunteers[id]);
    //             if (currentUser.email === (volunteers[id].email)) {

    //                 const vol = {
    //                     fname: volunteers[id].fname,
    //                     lname: volunteers[id].lname,
    //                     email: currentUser.email,
    //                     phone: volunteers[id].phone,
    //                     status: false,
    //                 };
    //                 eventRef.push(vol);
    //                 volunteerList.push({ id, ...volunteers[id] })
    //             }
    //         }
    //     });


    // }

    return (
        <div>
            <h1>{event.name}</h1>
            <button> <Link event= {event} to="/upload-completion-form"> Upload </Link></button>
        </div>
    )
}
