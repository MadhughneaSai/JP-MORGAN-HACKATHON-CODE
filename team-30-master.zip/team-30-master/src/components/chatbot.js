import React, { useState } from 'react';
import mystyle from "../css/dashboard.css"

export default function Chatbot() {
    const [show, setShow] = useState(false);
    return (
        <>
            <button className="btn btn-danger" style={{
                position: "fixed",
                top: "90%",
                left: "90%"
            }} onClick={() => {
                setShow(!show)
            }}>
                <span>
                    <i class="fas fa-question"></i></span>
            </button>

            {
                show === true ?
                    <iframe class="chatbot" width="350" height="430" allow="microphone;" src="https://console.dialogflow.com/api-client/demo/embedded/8b3a433e-0f82-4bab-a77c-30ef395dac06"></iframe>
                    : ""
            }
        </>


    );
}