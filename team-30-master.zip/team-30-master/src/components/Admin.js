import React from 'react';
import Header from "./Header";
import Footer from "./Footer"
import Chatbot from "./chatbot"
import "../css/admin.css"
import { Link } from 'react-router-dom'
import adminEventForm from "./adminEventForm"
import EventDisplay from "./eventDisplay"

export default function () {

    return (
        <>
            <Header />
            <h1 style={{
                position: "absolute",
                top: "11%"
            }}>
                Events
            </h1>

            <button className="btn btn-warning" style={{
                position: "fixed",
                top: "2%",
                left: "70%",
                zIndex: "10"
            }}>
                <Link to="/adminEventForm">AddEvent</Link>
            </button>

            <EventDisplay />

            <Footer />
            <Chatbot />
        </>
    );
}