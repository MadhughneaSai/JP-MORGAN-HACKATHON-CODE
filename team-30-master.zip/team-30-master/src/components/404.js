import React from 'react'

const filenotfound = () => {
    return (
        <div>
            <h1>404</h1>
            <p>FNF</p>
        </div>
    )
}

export default filenotfound
