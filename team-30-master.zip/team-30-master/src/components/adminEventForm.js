import React, { useState } from 'react'
import "firebase/auth"
import firebase from 'firebase';
import ScriptTag from 'react-script-tag';
import { useAuth } from "../contexts/AuthContext"
import { Link } from "react-router-dom"
import { v4 as uuid } from "uuid";
import "../css/signup.css"
import Footer from './Footer';

export default function CRUD() {
    <>  <script src="https://www.gstatic.com/firebasejs/7.2.3/firebase-database.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.24.0/firebase-auth.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.24.0/firebase-database.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.2.3/firebase.js"></script>
    </>
    const [name, setName] = useState("")
    const [desc, setDesc] = useState("")
    const [date, setDate] = useState("")
    const { currentUser } = useAuth()


    const handleNameOnChange = (e) => {
        setName(e.target.value);
    };
    const handleDescOnChange = (e) => {
        setDesc(e.target.value);
    }
    const handleDateOnChange = (e) => {
        setDate(e.target.value);
    }
    console.log(currentUser.email);
    const createUser = () => {
        const eventRef = firebase.database().ref("event")
        const event = {
            name,
            desc,
            date
        };
        eventRef.push(event);
    };



    return (
        <div>
            <form class="box1">
                <br/>
                <h1>ADD EVENT</h1>
                <input type="text" onChange={handleNameOnChange} value={name} placeholder="Event Name" />
                <input type="text" onChange={handleDescOnChange} value={desc} placeholder="Description" />
                <input type="text" onChange={handleDateOnChange} value={date} placeholder="Date of Event" />
                <button class="btn1" onClick={createUser} ><Link to="/admin" >Add Event</Link></button>
            </form>
            <Footer />
        </div>
        
    )
}
