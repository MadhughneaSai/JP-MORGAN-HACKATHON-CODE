import React, { useEffect, useState } from 'react'
import firebase from 'firebase';
import { useAuth } from "../contexts/AuthContext"
import EventProfile from './eventProfile';
import "../css/admin.css"

export default function CRUD2() {
    <>  <script src="https://www.gstatic.com/firebasejs/7.2.3/firebase-database.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.24.0/firebase-auth.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.24.0/firebase-database.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.2.3/firebase.js"></script>
    </>

    const [userList, setUserList] = useState();
    const { currentUser } = useAuth()
    useEffect(() => {
        const userRef = firebase.database().ref("event");
        const parRef = firebase.database().ref("event");

        userRef.on('value', (snapshot) => {
            const users = snapshot.val();
            const userList = [];
            for (let id in users) {
                console.log(users[id].email);
                userList.push({ id, ...users[id] })
                // if (currentUser.email === (users[id].email)) {
                //     
                // }
            }
            setUserList(userList);
        });
    }, []);

    return (
        <>
            
                {/* <div className="admin-events"> */}
                    <div className="filter"></div>
                    <div className="volunteer-profile">
                    {userList ? userList.map((user, index) => <EventProfile user={user} key={index} />) : ''}
                </div>

            {/* /* <div className="participant">
                <ul>
                    {userList ? userList.map((user, index) => {
                        return (<>
                            <li>{userList}</li>
                        </>
                        )
                    }) : ""}
                </ul>
            </div> */ }
        </>
    )
}
