import React from 'react';
import { useState } from 'react';
import firebase from '../firebase';

export default function Chat() {
    const [ask, setask] = useState(false);
    const [inp, setinp] = useState("");
    const [val, setval] = useState({
        question: ''
    }
    );

    const add = () => {
        alert("Hello")
        let inpE = inp;
        firebase.database().ref().child('question').push({
            question: inpE,
        },
            err => {
                if (err)
                    console.log(err);
            }
        )
    }

    return (
        <>
            <button onClick={() => {
                setask(!ask)
            }} className="btn btn-success">
                Ask Question
            </button>
            <button onClick={() => { add() }} className="btn btn-warning">
                Add
            </button>

            {
                ask === true ? <input type="text" name="question" id="question" onChange={(e) => {
                    setinp(e.target.value);
                    console.log(inp);
                }} value={inp} /> : ""
            }

            <div className="questions">
                <h1>Questions</h1>
                <ul>
                    <li>What's Up Bro ? </li>
                </ul>
            </div>
        </>
    );
}