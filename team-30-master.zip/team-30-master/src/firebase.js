import firebase from "firebase/app"
import "firebase/auth"


const firebaseConfig = {
    // apiKey: "AIzaSyC5fUx5f5iItXsh-NjxHKx87snfKFNizMA",
    // authDomain: "cfg-prac.firebaseapp.com",
    // databaseURL: "https://cfg-prac-default-rtdb.firebaseio.com",
    // projectId: "cfg-prac",
    // storageBucket: "cfg-prac.appspot.com",
    // messagingSenderId: "80362662700",
    // appId: "1:80362662700:web:e356975dbec8a31209da89",
    // measurementId: "G-J4LRFPPEJG"

    apiKey: "AIzaSyBm0BrO55IY2HwImTPR81su1hcoWaFGpk4",
    authDomain: "cfg-hackathon.firebaseapp.com",
    databaseURL: "https://cfg-hackathon-default-rtdb.firebaseio.com",
    projectId: "cfg-hackathon",
    storageBucket: "cfg-hackathon.appspot.com",
    messagingSenderId: "1039533379194",
    appId: "1:1039533379194:web:f082dafaa043a70ce7f5c3",
    measurementId: "G-7BJZEWH6LP"
}

const app = firebase.initializeApp(firebaseConfig);
// export const db = firebase.database().ref();
export const auth = app.auth();
export default app;