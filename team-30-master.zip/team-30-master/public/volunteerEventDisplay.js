import React, { useEffect, useState } from 'react'
import firebase from 'firebase';
import { useAuth } from "../contexts/AuthContext"
import VolunterEventProfile from './volunteerEventProfile';
import "../css/admin.css"

export default function CRUD2() {
    <>  <script src="https://www.gstatic.com/firebasejs/7.2.3/firebase-database.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.24.0/firebase-auth.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.24.0/firebase-database.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.2.3/firebase.js"></script>
    </>
    const { currentUser } = useAuth()
    const [userList, setUserList] = useState();



    useEffect(() => {
        const userRef = firebase.database().ref("event");
        userRef.on('value', (snapshot) => {
            const users = snapshot.val();
            const userList = [];
            for (let id in users) {
                console.log(users[id].email);
                userList.push({ id, ...users[id] })
                // if (currentUser.email === (users[id].email)) {
                //     
                // }
            }
            setUserList(userList);
        });
    }, []);

    return (
        <>
            <div className="filter"></div>
            <div className="volunteer-profile">
                {userList ? userList.map((event, index) => <VolunterEventProfile event={event} key={index} />) : ''}
            </div>
        </>
                )
}
