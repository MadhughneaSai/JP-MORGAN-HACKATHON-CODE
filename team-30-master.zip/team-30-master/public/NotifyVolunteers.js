import React from 'react'
import "firebase/auth"
import firebase from 'firebase';
import ScriptTag from 'react-script-tag';
import { useAuth } from "../contexts/AuthContext"
import { Link } from "react-router-dom"
import { v4 as uuid } from "uuid";
import emailjs from "emailjs-com";
export default function NotifyVolunteers() {

    function sendEmail(e) {
        e.preventDefault();
        emailjs.sendForm('service_cf1ywt4', 'template_kn8lcic', "user_LGum0WyxbmW8Q6yLkVehG")
    }

    return (
        <div>
            <ScriptTag isHydrating={true} type="text/javascript" src="https://smtpjs.com/v3/smtp.js" />
            <form method="post" onSubmit={sendEmail}>
                <input type="button" value="Send Email"
                />
            </form>
        </div>
    )
}
